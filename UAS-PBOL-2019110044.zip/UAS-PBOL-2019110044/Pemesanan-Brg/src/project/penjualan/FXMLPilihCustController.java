/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package project.penjualan;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author LIKMI
 */
public class FXMLPilihCustController implements Initializable {

    private int hasil=0;
    private String idmemberhasil=""; 
  
    @FXML
    private TableView<CustModel> tbvcust;
    @FXML
    private ComboBox<String> cbpilih;
    @FXML
    private Button btnpilih;
    @FXML
    private Button btnbatal;
    @FXML
    private TextField txtcari;
    @FXML
    private Button btncari;

    public int getHasil(){return(hasil);}
    public String getIdmemberhasil(){return(idmemberhasil);}
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cbpilih.setItems(FXCollections.observableArrayList
            ("ID Cust","Nama"));
        cbpilih.getSelectionModel().select(0);
        showdata("idcust","");// TODO
    }    

    public void showdata(String f, String i){
        ObservableList<CustModel> data= FXMLDocumentController.dtcust.CariCust(f,i);    
        if(data.isEmpty()){    
            data=FXMLDocumentController.dtcust.Load();
            txtcari.setText("");       
        }
        if(data!=null){   tbvcust.getColumns().clear();           
             tbvcust.getColumns().clear();            
            tbvcust.getItems().clear();
           TableColumn col=new TableColumn("ID");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("idcust"));
            tbvcust.getColumns().addAll(col);
            col=new TableColumn("NAMA");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("nama"));
            tbvcust.getColumns().addAll(col);
            col=new TableColumn("ALAMAT");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("alamat"));
            tbvcust.getColumns().addAll(col);
            col=new TableColumn("NO.TELP");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("notelp"));
            tbvcust.getColumns().addAll(col);
            col=new TableColumn("TOTAL");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("total"));
            tbvcust.getColumns().addAll(col); 
            col=new TableColumn("KATEGORI");
            col.setCellValueFactory(new PropertyValueFactory<CustModel, String>("status"));
            tbvcust.getColumns().addAll(col);

            
            tbvcust.setItems(data);
    }else {  Alert a=new Alert(Alert.AlertType.ERROR,"Data kosong",ButtonType.OK);
            a.showAndWait();
            tbvcust.getScene().getWindow().hide();;
        }                
    }
    
    @FXML
    private void pilihklik(ActionEvent event) {
        hasil=1;
        int pilihan=tbvcust.getSelectionModel().getSelectedCells().get(0).getRow();
        idmemberhasil=tbvcust.getSelectionModel().getSelectedItem().getIdcust().toString();
        btnpilih.getScene().getWindow().hide();
    }

    @FXML
    private void batalklik(ActionEvent event) {
        hasil=0;
        btnbatal.getScene().getWindow().hide();   
    }

    @FXML
    private void cariklik(ActionEvent event) {
        showdata(cbpilih.getSelectionModel().getSelectedItem(), txtcari.getText());
    }
    
}
