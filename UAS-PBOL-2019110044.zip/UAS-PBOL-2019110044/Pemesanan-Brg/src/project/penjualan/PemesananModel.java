/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.penjualan;

import java.sql.Date;

/**
 *
 * @author LIKMI
 */
public class PemesananModel {
    private String nopesan, idcust, nama;
    private Date tgl;
    
    public String getNopesan() {
        return nopesan;
    }

    public void setNopesan(String nopesan) {
        this.nopesan = nopesan;
    }

    public String getIdcust() {
        return idcust;
    }

    public void setIdcust(String idcust) {
        this.idcust = idcust;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public Date getTgl() {
        return tgl;
    }

    public void setTgl(Date tgl) {
        this.tgl = tgl;
    }
}
