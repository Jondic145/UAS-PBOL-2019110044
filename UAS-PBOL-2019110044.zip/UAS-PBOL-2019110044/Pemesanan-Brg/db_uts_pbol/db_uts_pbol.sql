-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.33 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for db_uts_pbol
CREATE DATABASE IF NOT EXISTS `db_uts_pbol` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `db_uts_pbol`;

-- Dumping structure for table db_uts_pbol.barang
CREATE TABLE IF NOT EXISTS `barang` (
  `kodebrg` varchar(50) NOT NULL DEFAULT '',
  `namabrg` varchar(30) NOT NULL DEFAULT '0',
  `tarif` double DEFAULT NULL,
  PRIMARY KEY (`kodebrg`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.

-- Dumping structure for table db_uts_pbol.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `idcust` varchar(50) NOT NULL DEFAULT '',
  `nama` varchar(30) DEFAULT NULL,
  `alamat` varchar(30) DEFAULT NULL,
  `notelp` varchar(50) DEFAULT NULL,
  `total` float DEFAULT NULL,
  PRIMARY KEY (`idcust`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.

-- Dumping structure for table db_uts_pbol.pemesanan
CREATE TABLE IF NOT EXISTS `pemesanan` (
  `nopesan` varchar(50) NOT NULL DEFAULT '0',
  `tgl` date DEFAULT NULL,
  `idcust` varchar(50) DEFAULT NULL,
  `nama` int(11) DEFAULT NULL,
  PRIMARY KEY (`nopesan`) USING BTREE,
  KEY `idcust` (`idcust`),
  CONSTRAINT `FK_pemesanan_customer` FOREIGN KEY (`idcust`) REFERENCES `customer` (`idcust`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.

-- Dumping structure for table db_uts_pbol.pemesanan_detil
CREATE TABLE IF NOT EXISTS `pemesanan_detil` (
  `nopesan` varchar(50) DEFAULT NULL,
  `kodebrg` varchar(50) DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  KEY `FK_pemesanan_detil_barang` (`kodebrg`),
  KEY `nopemesanan` (`nopesan`) USING BTREE,
  CONSTRAINT `FK_pemesanan_detil_barang` FOREIGN KEY (`kodebrg`) REFERENCES `barang` (`kodebrg`),
  CONSTRAINT `FK_pemesanan_detil_pemesanan` FOREIGN KEY (`nopesan`) REFERENCES `pemesanan` (`nopesan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Data exporting was unselected.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
