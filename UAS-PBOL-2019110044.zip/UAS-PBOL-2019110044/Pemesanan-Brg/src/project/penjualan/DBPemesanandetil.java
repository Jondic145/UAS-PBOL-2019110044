/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.penjualan;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author LIKMI
 */
public class DBPemesanandetil {

    private PemesanandetilModel dt = new PemesanandetilModel();

    public PemesanandetilModel getPemesanandetilModel() {
        return (dt);
    }

    public void setPemesanandetilModel(PemesanandetilModel s) {
        dt = s;
    }

    public ObservableList<PemesanandetilModel> Load(String kode) {
        try {
            ObservableList<PemesanandetilModel> tableData = FXCollections.observableArrayList();
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("Select p.nopesan,b.kodebrg,b.namabrg,p.jumlah,b.tarif "
                    + "from pemesanan_detil p join barang b on(p.kodebrg=b.kodebrg) WHERE nopesan LIKE '" + kode + "'");
            int i = 1;
            while (rs.next()) {
                PemesanandetilModel d = new PemesanandetilModel();
                d.setNopesan(rs.getString("nopesan"));
                d.setKodebrg(rs.getString("kodebrg"));
                d.setNamabrg(rs.getString("namabrg"));
                d.setJumlah(rs.getInt("jumlah"));
                d.setTarif(rs.getDouble("tarif"));

                double total = 0;
                int jumlah = rs.getInt("jumlah");
                double tarif = rs.getDouble("tarif");
                total = jumlah * (float) tarif;
                d.setTotal(total);

                tableData.add(d);
                i++;
            }
            con.tutupKoneksi();
            return tableData;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int validasi(String nomor) {
        int val = 0;
        try {
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("select count(*) as jml from pemesanan_detil where nopesan = '" + nomor + "'");
            while (rs.next()) {
                val = rs.getInt("jml");
            }
            con.tutupKoneksi();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return val;
    }

    public boolean insert() {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("insert into pemesanan_detil (nopesan,kodebrg,jumlah) values (?,?,?)");
            con.preparedStatement.setString(1, getPemesanandetilModel().getNopesan());
            con.preparedStatement.setString(2, getPemesanandetilModel().getKodebrg());
            con.preparedStatement.setInt(3, getPemesanandetilModel().getJumlah());
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
            berhasil = false;
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public boolean delete(String nomor, String kode) {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();;
            con.preparedStatement = con.dbKoneksi.prepareStatement("delete from pemesanan_detil where nopesan  = ? and kodebrg = ?");
            con.preparedStatement.setString(1, nomor);
            con.preparedStatement.setString(2, kode);
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public boolean deleteall(String nomor) {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();;
            con.preparedStatement = con.dbKoneksi.prepareStatement("delete from pemesanan_detil where nopesan  = ?");
            con.preparedStatement.setString(1, nomor);
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public boolean update() {
        boolean berhasil = false;
        Koneksi con = new Koneksi();
        try {
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("update pemesanan_detil set kodebrg = ?, jumlah = ?  where  nopesan= ? ");
            con.preparedStatement.setString(1, getPemesanandetilModel().getKodebrg());
            con.preparedStatement.setInt(2, getPemesanandetilModel().getJumlah());
            con.preparedStatement.setString(3, getPemesanandetilModel().getNopesan());
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {
            e.printStackTrace();
            berhasil = false;
        } finally {
            con.tutupKoneksi();
            return berhasil;
        }
    }

    public ObservableList<PemesanandetilModel> CariDetil(String kode) {
        try {
            ObservableList<PemesanandetilModel> tableData;
            tableData = FXCollections.observableArrayList();
            Koneksi con = new Koneksi();
            con.bukaKoneksi();
            con.statement = (Statement) con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("Select p.nopesan,j.kodebrg,b.namabrg,p.jumlah,b.tarif "
                    + "from pemesanan_detil p join barang b on(p.kodebrg=b.kodebrg)"
                    + "WHERE nopesan LIKE '" + kode + "'");
            int i = 1;
            while (rs.next()) {
                PemesanandetilModel d = new PemesanandetilModel();
                d.setNopesan(rs.getString("nojual"));
                d.setKodebrg(rs.getString("kodebrg"));
                d.setKodebrg(rs.getString("namabrg"));
                d.setJumlah(rs.getInt("jumlah"));
                d.setTarif(rs.getDouble("tarif"));

                double total = 0;
                int jumlah = rs.getInt("jumlah");
                double tarif = rs.getDouble("tarif");

                total = jumlah * (float) tarif;
                d.setTotal(total);
                tableData.add(d);
                i++;
            }
            con.tutupKoneksi();
            return tableData;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
