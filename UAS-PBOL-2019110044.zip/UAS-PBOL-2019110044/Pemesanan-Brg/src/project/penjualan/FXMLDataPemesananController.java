/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package project.penjualan;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author JD
 */
public class FXMLDataPemesananController implements Initializable {

    @FXML
    private AnchorPane txtidcust;
    @FXML
    private TextField txtnopesan;
    @FXML
    private TextField txttotal;
    @FXML
    private Button btnawal;
    @FXML
    private Button btnsebelum;
    @FXML
    private Button btnsesudah;
    @FXML
    private Button btntambah;
    @FXML
    private Button btnupdate;
    @FXML
    private Button btnhapus;
    @FXML
    private TableView<PemesanandetilModel> tbvdetil;
    @FXML
    private DatePicker dptanggal;
    @FXML
    private TableView<PemesananModel> tbvpesanan;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showdata();
        tbvdetil.getSelectionModel().selectFirst(); //ini untuk inisialisasi baris pertama
        tbvdetil.getSelectionModel().selectFirst();
        setdata();
    }

    @FXML
    public void setdata() {
        txtnopesan.setText(tbvpesanan.getSelectionModel().getSelectedItem().getNopesan());
        dptanggal.setValue(tbvpesanan.getSelectionModel().getSelectedItem().getTgl().toLocalDate());
        txtidcust.setId(tbvpesanan.getSelectionModel().getSelectedItem().getIdcust());
        showdatadetil();
    }

    public void showdata() {
        ObservableList<PemesananModel> data = FXMLDocumentController.dtpesan.Load();
        if (data != null) {
            tbvpesanan.getColumns().clear();
            tbvpesanan.getItems().clear();
            TableColumn col = new TableColumn("NO.PESAN");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
            tbvpesanan.getColumns().addAll(col);
            col = new TableColumn("TGL");
            //col.setCellValueFactory(new PropertyValueFactory<JualModel, String>("tgl"));
            col.setCellValueFactory(new FormattedDateValueFactory<PemesananModel>("tgl", "dd-MMM-yyyy"));
            tbvpesanan.getColumns().addAll(col);
            col = new TableColumn("IDCUST");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("idcust"));
            tbvpesanan.getColumns().addAll(col);
            col = new TableColumn("NAMA");
            col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nama"));
            tbvpesanan.getColumns().addAll(col);

            tbvpesanan.setItems(data);
        } else {
            Alert a = new Alert(Alert.AlertType.ERROR, "Data kosong", ButtonType.OK);
            a.showAndWait();
            tbvpesanan.getScene().getWindow().hide();;
        }
    }

    public void showdatadetil() {

        ObservableList<PemesanandetilModel> data = FXMLDocumentController.dtpesandetil.Load(txtnopesan.getText());
        if (data != null) {

            tbvdetil.getColumns().clear();
            tbvdetil.getItems().clear();

            TableColumn col = new TableColumn("NO.PESAN");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("nopesan"));
            tbvdetil.getColumns().addAll(col);

            col = new TableColumn("KODE BRG");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("kodebrg"));
            tbvdetil.getColumns().addAll(col);

            col = new TableColumn("NAMA BRG");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("namabrg"));
            tbvdetil.getColumns().addAll(col);

            col = new TableColumn("JUMLAH");
            col.setCellValueFactory(new PropertyValueFactory<PemesanandetilModel, String>("jumlah"));
            tbvdetil.getColumns().addAll(col);

            col = new TableColumn("TARIF");
            //col.setCellValueFactory(new PropertyValueFactory<JualdetilModel, String>("tarif"));
            col.setCellValueFactory(new FormattedDouble<PemesanandetilModel>("tarif", "#,###,##0"));
            tbvdetil.getColumns().addAll(col);

            col = new TableColumn("TOTAL");
            //col.setCellValueFactory(new PropertyValueFactory<JualdetilModel, String>("total"));
            col.setCellValueFactory(new FormattedDouble<PemesanandetilModel>("total", "#,###,##0"));
            tbvdetil.getColumns().addAll(col);

            tbvdetil.setItems(data);

            double totalall = 0;
            for (int i = 0; i < tbvdetil.getItems().size(); i++) {
                PemesanandetilModel n = tbvdetil.getItems().get(i);
                totalall += n.getTotal();
            }
            txttotal.setText(String.valueOf(totalall));

        } else {
            Alert a = new Alert(Alert.AlertType.ERROR, "Data kosong", ButtonType.OK);
            a.showAndWait();
            tbvdetil.getScene().getWindow().hide();;
        }
    }

//    @FXML
//    private void cariData(KeyEvent event) {
//        PemesananModel s = new PemesananModel();
//        String key = searchjual.getText();
//        if (key != "") {
//            ObservableList<PemesananModel> data = FXMLDocumentController.dtpesan.CariJual(key);
//            ObservableList<PemesanandetilModel> data2 = FXMLDocumentController.dtpesandetil.CariDetil(key);
//
//            if (data != null) {
//                tbvjual.getColumns().clear();
//                tbvjual.getItems().clear();
//                TableColumn col = new TableColumn("NO.PESAN");
//                col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
//                tbvjual.getColumns().addAll(col);
//                col = new TableColumn("TGL");
//                col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("tgl"));
//                tbvjual.getColumns().addAll(col);
//                col = new TableColumn("IDCUT");
//                col.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("idcust"));
//                tbvjual.getColumns().addAll(col);
//                tbvjual.setItems(data);
//
//                tbvdetil.getColumns().clear();
//                tbvdetil.getItems().clear();
//                TableColumn col2 = new TableColumn("NO.PESAN");
//                col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("nopesan"));
//                tbvdetil.getColumns().addAll(col2);
//                col2 = new TableColumn("KODE BRG");
//                col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("kodebrg"));
//                tbvdetil.getColumns().addAll(col2);
//                col2 = new TableColumn("jumlah");
//                col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("jumlah"));
//                tbvdetil.getColumns().addAll(col2);
//                col2 = new TableColumn("tarif");
//                col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("tarif"));
//                tbvdetil.getColumns().addAll(col2);
//                col2 = new TableColumn("total");
//                col2.setCellValueFactory(new PropertyValueFactory<PemesananModel, String>("total"));
//                tbvdetil.getColumns().addAll(col2);
//                tbvdetil.setItems(data2);
//
//            } else {
//                Alert a = new Alert(Alert.AlertType.ERROR, "Data kosong", ButtonType.OK);
//                a.showAndWait();
//                tbvpesanan.getScene().getWindow().hide();;
//            }
//        } else {
//            showdata();
//        }
//    }

    @FXML
    private void awalklik(ActionEvent event) {
    }

    @FXML
    private void sebelumklik(ActionEvent event) {
    }

    @FXML
    private void btnsesudah(ActionEvent event) {
    }

    @FXML
    private void tambahklik(ActionEvent event) {
    }

    @FXML
    private void updateklik(ActionEvent event) {
    }

    @FXML
    private void hapusklik(ActionEvent event) {
    }

}
