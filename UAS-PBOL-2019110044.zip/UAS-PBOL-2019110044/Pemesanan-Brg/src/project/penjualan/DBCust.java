/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.penjualan;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author LIKMI
 */
public class DBCust {
    private CustModel dt=new CustModel();    
    public CustModel getCustModel(){ return(dt);}
    public void setCustModel(CustModel s){ dt=s;}
    
    public ObservableList<CustModel>  Load() {
        try {
            ObservableList<CustModel> tableData=FXCollections.observableArrayList();
            Koneksi con = new Koneksi();            
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery("Select idcust, nama, alamat, notelp, total from customer");
int i = 1;
            while (rs.next()) {
                CustModel d = new CustModel();
                d.setIdcust(rs.getString("idcust"));
                d.setNama(rs.getString("nama"));
                d.setAlamat(rs.getString("alamat"));
                d.setNotelp(rs.getInt("notelp"));
                d.setTotal(rs.getDouble("total"));  
                
                double total = rs.getDouble("total");
                String status;

                if (total >= 1000000) {
                    status = "Express";
                } else if (total >= 500000) {
                    status = "Reguler";
                } else {
                    status = "Reguler";
                }
                d.setStatus(status);

                tableData.add(d);
                i++;           
            }
            con.tutupKoneksi();            
            return tableData;
        } catch (Exception e) {            
            e.printStackTrace();            
            return null;        
        }
    }
    
 public int validasi(String nomor) {
        int val = 0;
        try {         
            Koneksi con = new Koneksi();            
            con.bukaKoneksi();
            con.statement = con.dbKoneksi.createStatement();
            ResultSet rs = con.statement.executeQuery(  "select count(*) as jml from customer where idcust = '" + nomor + "'");
            while (rs.next()) {                
                val = rs.getInt("jml");            
            }            
            con.tutupKoneksi();
        } catch (SQLException e) {            
            e.printStackTrace();        
        }
        return val;
    }
   
 public boolean insert() {
        boolean berhasil = false;        
        Koneksi con = new Koneksi();
        try {       
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("insert into customer (idcust, nama, alamat, notelp, total) values (?,?,?,?,?)");
            con.preparedStatement.setString(1, getCustModel().getIdcust());
            con.preparedStatement.setString(2, getCustModel().getNama());
            con.preparedStatement.setString(3, getCustModel().getAlamat());
            con.preparedStatement.setInt(4, getCustModel().getNotelp());
            con.preparedStatement.setDouble(5, getCustModel().getTotal());        
            con.preparedStatement.executeUpdate();
            berhasil = true;
        } catch (Exception e) {            
            e.printStackTrace();            
            berhasil = false;
        } finally {            
            con.tutupKoneksi();            
            return berhasil;        
        }    
     }
   
public boolean delete(String nomor) {
        boolean berhasil = false;        
        Koneksi con = new Koneksi();
        try {            
            con.bukaKoneksi();;
            con.preparedStatement = con.dbKoneksi.prepareStatement("delete from customer where idcust  = ? ");
            con.preparedStatement.setString(1, nomor);
            con.preparedStatement.executeUpdate();            
            berhasil = true;
        } catch (Exception e) {            
            e.printStackTrace();
        } finally {            
            con.tutupKoneksi();            
            return berhasil;        
        }
    }

public boolean update() {
        boolean berhasil = false;        
        Koneksi con = new Koneksi();
        try {            
            con.bukaKoneksi();
            con.preparedStatement = con.dbKoneksi.prepareStatement("update customer set nama = ?, alamat = ?, notelp = ?, total = ?  where  idcust = ? ");
            con.preparedStatement.setString(1, getCustModel().getNama());
            con.preparedStatement.setString(2, getCustModel().getAlamat());
            con.preparedStatement.setInt(3, getCustModel().getNotelp());
            con.preparedStatement.setDouble(4, getCustModel().getTotal());
            con.preparedStatement.setString(5, getCustModel().getIdcust());
            con.preparedStatement.executeUpdate();           
            berhasil = true;
        } catch (Exception e) {            
            e.printStackTrace();            
            berhasil = false;
        } finally {            
            con.tutupKoneksi();            
            return berhasil;        
        }    
        }

public ObservableList<CustModel>  CariCust(String kode, String nama) {
        try {    
            ObservableList<CustModel> 	tableData;
            tableData = FXCollections.observableArrayList();
            Koneksi con = new Koneksi(); 
            con.bukaKoneksi();
            con.statement = (Statement) con.dbKoneksi.createStatement();
            ResultSet rs = (ResultSet) con.statement.executeQuery("select * from customer WHERE idcust LIKE '" + kode + "%' OR nama LIKE '" + nama + "%'");
        int i = 1;
        while(rs.next()){
             CustModel d = new CustModel();
                d.setIdcust(rs.getString("idcust"));
                d.setNama(rs.getString("nama"));
                d.setAlamat(rs.getString("alamat"));
                d.setNotelp(rs.getInt("notelp"));
                d.setTotal(rs.getDouble("total"));

                double total = rs.getDouble("total");
                String status;

                if (total >= 1000000) {
                    status = "Express";
                } else if (total >= 500000) {
                    status = "Reguler";
                } else {
                    status = "Reguler";
                }
                d.setStatus(status);

                tableData.add(d);
                i++;
        }
        con.tutupKoneksi();
        return tableData;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }

public void print(){
        Koneksi con = new Koneksi(); 
        String is = "./src/project/penjualan/reportCust.jasper";
        Map map = new HashMap();
        map.put("p_periode", "Desember");
        con.bukaKoneksi();
        try { 
            JasperPrint jasperPrint =
                JasperFillManager.fillReport(is, map,  con.dbKoneksi);
            JasperViewer.viewReport(jasperPrint, false);
        } 
        catch (Exception ex) { ex.printStackTrace();  }   
        con.tutupKoneksi();         
    }

}
